@echo off
setlocal EnableDelayedExpansion

:: AUTO CONFIG FORÇADO (CI MODE)
set "_target=D:\Files\DVD"
set "_repo=D:\Files\Updates"
set "_dism=HostOS"

set "_Net35=1"
set "_Cleanup=1"
set "_ResetBase=1"

set "_wim2esd=1"
set "_esdcompress=4"
set "_ISO=1"

set "_AddDrivers=1"
set "_Drv_Source=D:\Files\Drivers"

set "_AutoStart=1"
set "_Silent=1"

goto :Main
